import boto3
import datetime

# Initialize boto3 client
iam_client = boto3.client('iam')
sns_client = boto3.client('sns')

# SNS topic ARN - replace with your SNS topic ARN
sns_topic_arn = 'arn:aws:sns:us-east-1:969036648835:cloud-security'

def lambda_handler(event, context):
    # Get list of all IAM users
    users = iam_client.list_users()
    
    for user in users['Users']:
        username = user['UserName']
        
        # List access keys for the user
        access_keys = iam_client.list_access_keys(UserName=username)
        
        for key in access_keys['AccessKeyMetadata']:
            key_id = key['AccessKeyId']
            last_used_response = iam_client.get_access_key_last_used(AccessKeyId=key_id)
            
            # Check if the access key has been used
            if 'LastUsedDate' in last_used_response['AccessKeyLastUsed']:
                last_used_date = last_used_response['AccessKeyLastUsed']['LastUsedDate']
                current_date = datetime.datetime.now(last_used_date.tzinfo)
                
                # Identify if the key hasn't been used for 3 days
                if (current_date - last_used_date).days > 3:
                    # This is where you could add logic to rotate the key and/or notify the user
                    print(f"Access Key {key_id} for user {username} has not been used for 3 days.")
                    
                    # Example notification (to be customized)
                    notification_message = f"Access Key {key_id} for IAM user {username} has not been used for 3 days. Consider rotating or deactivating it."
                    sns_client.publish(
                        TopicArn=sns_topic_arn,
                        Message=notification_message,
                        Subject='Unused AWS Access Key Detected'
                    )
            else:
                print(f"Access Key {key_id} for user {username} has never been used.")

